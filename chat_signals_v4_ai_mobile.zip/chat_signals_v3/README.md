# Chat Signals V4 — Mobile + AI edition

## What's improved
- A visible three-dot menu (⋮) with help, CSV export, and clear-session actions.
- A more careful local report: it reports transcript counts and labels keyword signals as weak indicators, not evidence of feelings.
- Optional AI interpretation through a Netlify Function and the OpenAI Responses API. The API key stays server-side.
- Video OCR still runs in the browser; only the reviewed text transcript is sent if the user presses **Analyse with AI**.

## Important: deploy through a Git-connected Netlify site
This version includes a Netlify Function, so do not use the old drag-and-drop static-only deploy method.

1. Extract this ZIP.
2. Create a GitHub repository and upload the contents of this folder, including the `netlify/functions/chat-analysis.mjs` file and `netlify.toml`.
3. In Netlify, choose **Add new project → Import an existing project**, connect GitHub, and select the repository.
4. Set the publish directory to `.` (no build command needed). Netlify detects the function from `netlify/functions`.
5. In Netlify project settings, add `OPENAI_API_KEY` with your OpenAI API key and `CHAT_SIGNALS_ACCESS_CODE` with a long private passcode only you know. Set both scopes to Functions (or all scopes). Never paste either secret into website code, GitHub, or this chat.
6. Optionally add `OPENAI_MODEL` with a model name enabled for your API account; default is `gpt-5.5`.
7. Trigger a new deploy after saving the environment variable.
8. Keep your existing `chatsignals.netlify.app` site name if Netlify lets you attach it to the new Git-connected project; otherwise deploy to a temporary Netlify URL first and then follow Netlify's site/domain settings to transfer or rename the site.

## AI costs and privacy
- ChatGPT subscriptions and OpenAI API billing are separate. AI calls require an API account with API billing/credits enabled; charges depend on usage and model.
- The AI function sends only the user-reviewed text transcript (up to 500 messages / 24,000 characters) to the OpenAI API. The video file is never sent to the AI function.
- Do not analyse chats without permission. Consider removing names and sensitive details before using AI.
- The AI endpoint requires the private access code configured in Netlify. Keep that code private and do not share it. This starter does not include persistent per-user quotas or advanced rate limiting; do not publish the access code or share it publicly.

## Local run
Static OCR can be previewed with a local web server. The AI endpoint only works when deployed with Netlify Functions and the environment variable configured.

## Known limitations
- OCR may merge, omit, duplicate or misread lines; always correct the transcript before analysis.
- Sender side is estimated from horizontal screen position and must be checked.
- This is not a psychological test, diagnosis, lie detector, or proof of love, attraction, intent, or relationship health. AI should be treated as a cautious interpretation of incomplete text.
